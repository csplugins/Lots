Cody Skala (cws26)
OS Project 4B POSIX Threads and Semaphores

To compile and run:
1. Navigate to the folder with the main.c file in a terminal
2. To make type: make
3. To run type: ./a.out
================================================================================
To use this program:
This program requires no user interaction after starting. A list of text appears
on screen that will show when an agent supplies items. The other lines will say
when a smoker makes and when they smoke the cigarette. The final list should
display agents providing materials 18 times, and smokers making and smoking a
cigarette 18 times as well. Each smoker should smoke three cigarettes.
