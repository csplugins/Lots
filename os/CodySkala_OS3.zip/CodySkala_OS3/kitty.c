#include "blackdos.h"

void main()
{
   PRINTS("     |\\      _,,,---,,_\r\n\0");
   PRINTS("     /,`.-\'`\'    -.  ;-;;,_\r\n\0");
   PRINTS("    |,4-  ) )-,_..;\\ (  `\'-\'\r\n\0");
   PRINTS("   \'---\'\'(_/--\'  `-\'\\_)\r\n\0");
   PRINTS("Soft Kitty, Warm Kitty,\r\n\0");
   PRINTS("  little ball of fur.\r\n\0");
   PRINTS("    Happy Kitty, Sleepy Kitty,\r\n\0");
   PRINTS("              purr, purr, purr.\r\n\0");
   END;
}
