This is Cody Skala (cws26) and here is my Algorithms Project 2.
Everything is included that needs to be and has been tested on a lab machine with Linux.
If anything is missing, please let me know so I may correct it accordingly.
----------------------------------------------------------------------------------------
PART 1
----------------------------------------------------------------------------------------
To execute the compression of this project, navigate to the folder with the make file
and type: make clean
Next, to compile and regenerate the files, type: make all
Finally to run, type: ./lzw435 c monkey.gif
This should run in about 5 seconds or less and make a file monkey.gif.lzw
To verify the correct file size on Linux, use the command: wc -c filename
Which should match the file size according to the rubric sheet.
----------------------------------------------------------------------------------------
To execute the  expansion of this project, navigate to the folder with the make file
folder and type: make clean
Next, to compile and regenerate the files, type: make all
To run, type ./lzw435 e monkey.gif.lzw
This should also run in under 5 seconds or less and make a file monkey.gif2
To verify the correct file size on Linux, use the command: wc -c filename
Which should match the file size according to the rubric sheet.
----------------------------------------------------------------------------------------
PART 2
----------------------------------------------------------------------------------------
To execute the compression of this project, navigate to the folder with the make file
and type: make clean
Next, to compile and regenerate the files, type: make all
Finally to run, type: ./lzw435M c monkey.gif
This should run in about 5 seconds or less and make a file monkey.gif.lzw2
To verify the correct file size on Linux, use the command: wc -c filename
Which should match the file size according to the rubric sheet.
----------------------------------------------------------------------------------------
To execute the  expansion of this project, navigate to the folder with the make file
folder and type: make clean
Next, to compile and regenerate the files, type: make all
To run, type ./lzw435M e monkey.gif.lzw2
This should also run in under 5 seconds or less and make a file monkey.gif2M
To verify the correct file size on Linux, use the command: wc -c filename
Which should match the file size according to the rubric sheet.
----------------------------------------------------------------------------------------
Overall, this was a fun project and learned a lot about LZW compression and look
forward to working with more algorithm projects as the semester goes along.
